import dependency-injector.containers as containers
import dependency-injector.providers as providers

class KindOfMessage:
    def __init__(self, message):
        self.message = message

class Love(KindOfMessage):
    def __init__(self, message):
        super().__init__(message)
        self.color = (225, 51, 153)
        self.border = "♥♥♥♥♥♥♥♥♥♥♥♥"

class Important(KindOfMessage):
    def __init__(self, message):
        super().__init__(message)
        self.color = (0, 225, 225)
        self.border = "!!!!!!!!!!!!"


class Warrior(KindOfMessage):
    def __init__(self, message):
        super().__init__(message)
        self.color = (225, 0, 0)
        self.border = "XXXXXXXXXXXX"


class Simple(KindOfMessage):
    def __init__(self, message):
        super().__init__(message)
        self.color = (225, 225, 225)
        self.border = ""


class Message:
    def __init__(self, kind):
        self.kind = kind