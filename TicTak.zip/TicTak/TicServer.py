import socket, time

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s.bind(('0.0.0.0', 11719))

clients = []
command_messeges = ["O", "X", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]

stop = False
print("[ Server Started ]")

while not stop:
    try:
        data, addr = s.recvfrom(1024)
        if addr not in clients:
            clients.append(addr)

        if data.decode('utf-8') == "New player connected" and len(clients) > 2:
            pass
        else:
            for client in clients:
                if addr != client:
                    s.sendto(data, client)

    except:
        print("\n[ Server Stopped ]")
        stop = True

s.close()
