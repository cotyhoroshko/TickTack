import pygame

area = pygame.Surface((450, 450))
area.fill((112, 60, 240))
pygame.draw.line(area, pygame.Color("White"), (0, 150), (450, 150))
pygame.draw.line(area, pygame.Color("White"), (0, 300), (450, 300))
pygame.draw.line(area, pygame.Color("White"), (150, 0), (150, 450))
pygame.draw.line(area, pygame.Color("White"), (300, 0), (300, 450))

pygame.image.save(area, "images/background.png")


