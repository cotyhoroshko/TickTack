import pygame
from button import Button


class PlayButton(Button):
    """Клас для ігрових клітинок"""
    def __init__(self, position, path_normal, path_touch, area, logic, path_image_o, path_image_x, button_high=145, button_weight=145):
        self.button_status = "Nothing"
        self.player = "X"
        super().__init__(position, path_normal, path_touch, area, button_high, button_weight, logic)

        self.path_image_X = path_image_x
        self.path_image_O = path_image_o

        self.X_image = pygame.image.load(self.path_image_X).convert()
        self.O_image = pygame.image.load(self.path_image_O).convert()

        self.X_image = pygame.transform.scale(self.X_image, (self.weight, self.high))
        self.O_image = pygame.transform.scale(self.O_image, (self.weight, self.high))
