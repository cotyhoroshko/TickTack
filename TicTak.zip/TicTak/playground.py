import pygame
from play_button import PlayButton
import socket
from modulenew import TextBox
import time


class Area:
    """Клас ігрового поля"""
    def __init__(self, screen, logic):
        self.positions = [(30, 30), (180, 30), (330, 30), (30, 180), (180, 180), (330, 180), (30, 330), (180, 330), (330, 330)]
        self.buttons = []
        for position in self.positions:
            self.buttons.append(PlayButton(position, "images/normal.png", "images/normal.png", screen.screen, logic, "images/O.png", "images/X.png"))
        self.button_status = "Nothing"
        self.player = "X"
        self.may_touch = True
        self.screen = screen
        self.name_is_entered = False
        self.name = "player"

        #Створення вікна вводу імені
        self.input_name = TextBox((155, 225, 200, 30), command=self.set_name,
                             clear_on_enter=True, inactive_on_enter=False)

        #Створення вікна вводу повідомлень
        self.input = TextBox((760, 470, 235, 30), command=self.add_and_send_message,
                             clear_on_enter=True, inactive_on_enter=False)

        #Створення клієнта
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self.sock.setblocking(False)
        self.sock.sendto(("New player connected").encode('utf-8'), ('255.255.255.255', 11719))

        self.times = 0
        self.unic = 20

    def set_name(self, id, message):
        self.name = message
        self.name_is_entered = True

    def add_message(self, message):
        self.screen.render_chat(message)

    def add_and_send_message(self, id, message):
        message = time.strftime("{%H:%M}") + "[" + self.name + "] " + message
        self.add_message(message)
        self.sock.sendto(message.encode('utf-8'), ('255.255.255.255', 11719))

    def play(self):
        for i in range(9):
            self.button_touch(self.buttons[i], i)
            self.draw_button(self.buttons[i], i)

    def draw_button(self, button_obj, i):
        """Виведення квадратика залежно від статусу"""
        #self.button_touch(button_obj, i)
        if button_obj.button_status == "Nothing":
            button_obj.area.blit(button_obj.normal_image, button_obj.position)
        if button_obj.button_status == "X":
            button_obj.area.blit(button_obj.X_image, button_obj.position)
        if button_obj.button_status == "O":
            button_obj.area.blit(button_obj.O_image, button_obj.position)

    def button_touch(self, button_obj, i):
        """Робить вигляд квадратика опираючись на дані про гравця і координати мишки"""
        if self.player == "X":
            if button_obj.button_rect.collidepoint(button_obj.logic.mouse_koorditations) and button_obj.button_status == "Nothing" and self.may_touch:
                self.sock.sendto("X".encode('utf-8'), ('255.255.255.255', 11719))
                self.sock.sendto(str(i).encode('utf-8'), ('255.255.255.255', 11719))
                self.may_touch = False
                button_obj.button_status = "X"
                self.unic = 1
                if self.times == 0:
                    self.unic = 1
                self.times += 1

                self.player = "O"
                print(button_obj.logic.mouse_koorditations)
        if self.player == "O":
            if button_obj.button_rect.collidepoint(button_obj.logic.mouse_koorditations) and button_obj.button_status == "Nothing" and self.may_touch:
                self.sock.sendto("O".encode('utf-8'), ('255.255.255.255', 11719))
                self.sock.sendto(str(i).encode('utf-8'), ('255.255.255.255', 11719))
                self.may_touch = False
                button_obj.button_status = "O"
                self.unic = 1
                if self.times == 0:
                    self.unic = 1
                self.times += 1

                self.player = "X"

        try:
            message = self.sock.recv(1024)
            message = message.decode('utf-8')

            if message == "X":
                self.player = "O"
                self.buttons[int(message)].button_status = self.player

                self.may_touch = True

            elif message == "O":
                self.player = "X"
                self.buttons[int(message)].button_status = self.player

                self.may_touch = True

            elif message in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]:
                if self.player == "X":
                    self.buttons[int(message)].button_status = "O"
                if self.player == "O":
                    self.buttons[int(message)].button_status = "X"

                self.may_touch = True

            else:
                self.add_message(message)
        except:
            pass