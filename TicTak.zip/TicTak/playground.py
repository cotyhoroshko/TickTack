import pygame
from play_button import PlayButton


class Area:
    """Клас ігрового поля"""
    def __init__(self, screen, logic):
        self.positions = [(30, 30), (180, 30), (330, 30), (30, 180), (180, 180), (330, 180), (30, 330), (180, 330), (330, 330)]
        self.buttons = []
        for position in self.positions:
            self.buttons.append(PlayButton(position, "images/normal.png", "images/normal.png", screen.screen, logic, "images/O.png", "images/X.png"))
        self.button_status = "Nothing"
        self.player = "X"

    def play(self):
        for i in self.buttons:
            self.button_touch(i)
            self.draw_button(i)

    def draw_button(self, button_obj):
        """Виведення квадратика залежно від статусу"""
        self.button_touch(button_obj)
        if button_obj.button_status == "Nothing":
            button_obj.area.blit(button_obj.normal_image, button_obj.position)
        if button_obj.button_status == "X":
            button_obj.area.blit(button_obj.X_image, button_obj.position)
        if button_obj.button_status == "O":
            button_obj.area.blit(button_obj.O_image, button_obj.position)

    def button_touch(self, button_obj):
        """Робить вигляд квадратика опираючись на дані про гравця і координати мишки"""
        if self.player == "X":
            if button_obj.button_rect.collidepoint(button_obj.logic.mouse_koorditations) and button_obj.button_status == "Nothing":
                button_obj.button_status = "X"
                self.player = "O"
        if self.player == "O":
            if button_obj.button_rect.collidepoint(button_obj.logic.mouse_koorditations) and button_obj.button_status == "Nothing":
                button_obj.button_status = "O"
                self.player = "X"