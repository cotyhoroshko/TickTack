import pygame


class Button:
    def __init__(self, position, path_normal, path_touch, area, button_high, button_weight, logic):
        self.position = position
        self.path_normal = path_normal
        self.path_touch = path_touch
        self.area = area
        self.high = button_high
        self.weight = button_weight
        self.logic = logic
        self.button_status = "Nothing"
        self.player = "X"

        self.normal_image = pygame.image.load(self.path_normal).convert()
        self.touch_image = pygame.image.load(self.path_touch).convert()

        self.normal_image = pygame.transform.scale(self.normal_image, (self.weight, self.high))
        self.touch_image = pygame.transform.scale(self.touch_image, (self.weight, self.high))
        self.button_rect = pygame.Rect(self.position, (self.weight, self.high))

        self.draw_button()

    def draw_button(self):
        """Виведення кнопки"""
        self.area.blit(self.normal_image, self.position)

    def button_touch(self):
        """Робить вигляд кнопки такий, ніби вона натиснута"""
        if self.button_rect.collidepoint(self.logic.mouse_koorditations) and self.logic.mouse_status == "Up":
            self.area.blit(self.normal_image, self.position)
        if self.button_rect.collidepoint(self.logic.mouse_koorditations) and self.logic.mouse_status == "Down":
            self.area.blit(self.touch_image, self.position)


class StartButton(Button):
    def __init__(self, position, path_normal, path_touch, area, button_high, button_weight, logic):
        super().__init__(position, path_normal, path_touch, area, button_high, button_weight, logic)
        self.start_bool = False

    def start(self):
        """Виходить з гри"""
        if self.button_rect.collidepoint(self.logic.mouse_koorditations) and self.logic.mouse_status == "Down":
            self.start_bool = True
        return self.start_bool


class ExitButton(Button):
    def __init__(self, position, path_normal, path_touch, area, button_high, button_weight, logic):
        super().__init__(position, path_normal, path_touch, area, button_high, button_weight, logic)

    def exit(self):
        """Виходить з гри"""
        if self.button_rect.collidepoint(self.logic.mouse_koorditations) and self.logic.mouse_status == "Down":
            self.logic.set_game_not_over(False)