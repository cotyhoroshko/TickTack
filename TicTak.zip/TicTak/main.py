import pygame
from game import Screen
from logic import Logic
from button import StartButton, ExitButton
from playground import Area


def check_get_down(get_down):
    if get_down == "DOWN":
        return -15
    elif get_down == "UP":
        return 15
    else:
        return 0


pygame.init()

screen = Screen(1000, 500)
logic = Logic()

area = Area(screen, logic)
start_button = StartButton((550, 200), "images/START.jpeg", "images/START_TOUCH.jpg", screen.screen, 100, 200, logic)
exit_button = ExitButton((550, 350), "images/OUT.jpeg", "images/OUT_TOUCH.jpg", screen.screen, 100, 200, logic)

X_image = pygame.image.load("images/X.png").convert()
O_image = pygame.image.load("images/O.png").convert()

X_image = pygame.transform.scale(X_image, (145, 145))
O_image = pygame.transform.scale(O_image, (145, 145))

name_entered = False
scroll_y = 0

while logic.get_game_not_over():

    if not name_entered:
        """Екран до вводу імені"""
        while not name_entered:
            screen.fill_screen_front("Enter your name", 32)
            logic.button_logic(area.input_name)
            area.input_name.update()
            area.input_name.draw(screen.screen)
            exit_button.button_touch()
            if area.name_is_entered:
                name_entered = True
            pygame.display.update()
            pygame.time.Clock().tick(60.0)
    else:
        """Екран, коли ім'я введено"""
        screen.fill_screen_background()

        get_down = logic.button_logic(area.input)
        scroll_y += check_get_down(get_down)
        screen.screen.blit(screen.intermediate, (760, scroll_y))

        note = logic.game_logic(area.buttons)

        start_button.button_touch()
        exit_button.button_touch()
        exit_button.exit()
        area.play()

        area.input.update()
        area.input.draw(screen.screen)

        if not area.may_touch:
            screen.fill_screen_front("The course of the opponent", 18)

        screen.show_player_now(area.player, O_image, X_image)

        if start_button.start():
            area = Area(screen, logic)
            start_button = StartButton((550, 200), "images/START.jpeg", "images/START_TOUCH.jpg", screen.screen, 100, 200, logic)
            exit_button = ExitButton((550, 350), "images/OUT.jpeg", "images/OUT_TOUCH.jpg", screen.screen, 100, 200, logic)

        if note != "Nothing":
            screen.fill_screen_front(note)
            area.may_touch = False
            note = None

        pygame.display.update()
        pygame.time.Clock().tick(60.0)




