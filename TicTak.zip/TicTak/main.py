import pygame
from game import Screen
from logic import Logic
from button import StartButton, ExitButton
from playground import Area

pygame.init()

screen = Screen()
logic = Logic()

area = Area(screen, logic)
start_button = StartButton((550, 200), "images/START.jpeg", "images/START_TOUCH.jpg", screen.screen, 100, 200, logic)
exit_button = ExitButton((550, 350), "images/OUT.jpeg", "images/OUT_TOUCH.jpg", screen.screen, 100, 200, logic)

X_image = pygame.image.load("images/X.png").convert()
O_image = pygame.image.load("images/O.png").convert()

X_image = pygame.transform.scale(X_image, (145, 145))
O_image = pygame.transform.scale(O_image, (145, 145))

while logic.get_game_not_over():
    screen.fill_screen_background()

    logic.button_logic()
    note = logic.game_logic(area.buttons)

    start_button.button_touch()
    exit_button.button_touch()
    exit_button.exit()

    area.play()
    screen.show_player_now(area.player, O_image, X_image)

    if start_button.start():
        area = Area(screen, logic)
        start_button = StartButton((550, 200), "images/START.jpeg", "images/START_TOUCH.jpg", screen.screen, 100, 200, logic)
        exit_button = ExitButton((550, 350), "images/OUT.jpeg", "images/OUT_TOUCH.jpg", screen.screen, 100, 200, logic)

    if note != "Nothing":
        screen.end_of_game(note)
        note = None
    pygame.display.update()
