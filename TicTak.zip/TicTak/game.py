import pygame
import string
#from input_pol import InputBox

class Screen:
    def __init__(self, wight=800, hight=500, fps=60, caption="TicTak"):
        self.wight = wight
        self.hight = hight
        self.fps = fps
        self._caption = caption
        self.bg_color = (50, 0, 180)

        self.screen = pygame.display.set_mode((self.wight, self.hight))
        pygame.display.set_caption(caption)
        self.screen.fill(self.bg_color)
        self._area_border = pygame.image.load("images/area_border.png").convert()
        self.screen.blit(self._area_border, (0, 0))
        self.background = pygame.image.load("images/background.png").convert()
        self.screen.blit(self.background, (25, 25))


        #Створення вікна повідомлень
        pygame.font.init()  # you have to call this at the start,
        self.myfont = pygame.font.SysFont('Comic Sans MS', 30)
        self.chat_string = ["CHAT"]


        self.intermediate = pygame.Surface((235, 500))

        i_a = self.intermediate.get_rect()
        x1 = i_a[0]
        x2 = x1 + i_a[2]
        a, b = (255, 0, 0), (60, 255, 120)
        y1 = i_a[1]
        y2 = y1 + i_a[3]
        h = y2 - y1
        rate = (float((b[0] - a[0]) / h),
                (float(b[1] - a[1]) / h),
                (float(b[2] - a[2]) / h)
                )
        for line in range(y1, y2):
            color = (min(max(a[0] + (rate[0] * line), 112), 240),
                     min(max(a[1] + (rate[1] * line), 60), 60),
                     min(max(a[2] + (rate[2] * line), 240), 240)
                     )
            pygame.draw.line(self.intermediate, color, (x1, line), (x2, line))

        self.y = 20
        self.f = pygame.font.SysFont('', 17)
        for l in self.chat_string:
            self.intermediate.blit(self.f.render(l, True, (255, 255, 255)), (10, self.y))
            self.y += 20

    def render_chat(self, message):
        self.intermediate.blit(self.f.render(message, True, (255, 255, 255)), (10, self.y))
        self.y += 20

    def set_caption(self):
        """Встановити заголовок вікна"""
        new_caption = input("Enter new caption: ")
        self._caption = new_caption

    def fill_screen_front(self, note, size=48):
        """Дії при завершенні гри"""
        string = pygame.font.SysFont('serif', size)
        text2 = string.render(note, 0, (255, 255, 255))
        surf = pygame.Surface((450, 450))
        surf.fill((60, 10, 180))
        surf.set_alpha(150)
        self.screen.blit(surf, (25, 25))
        self.screen.blit(text2, (120, 170))

    def fill_screen_background(self):
        """Заповнення фону"""
        surf = pygame.Surface((450, 450))
        surf.fill((60, 10, 180))
        self.screen.blit(surf, (25, 25))

    def show_player_now(self, player, O_image, X_image):
        """Виведення фігури грвця, який зараз ходить"""
        if player == "X":
            self.screen.blit(X_image, (575, 30))
        else:
            self.screen.blit(O_image, (575, 30))


