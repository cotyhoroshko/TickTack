import pygame


class Screen:
    def __init__(self, wight=800, hight=500, fps=60, caption="TicTak"):
        self.wight = wight
        self.hight = hight
        self.fps = fps
        self._caption = caption
        self.bg_color = (50, 0, 180)

        self.screen = pygame.display.set_mode((self.wight, self.hight))
        pygame.display.set_caption(caption)
        self.screen.fill(self.bg_color)
        self._area_border = pygame.image.load("images/area_border.png").convert()
        self.screen.blit(self._area_border, (0, 0))
        self.background = pygame.image.load("images/background.png").convert()
        self.screen.blit(self.background, (25, 25))

    def set_caption(self):
        """Встановити заголовок вікна"""
        new_caption = input("Enter new caption: ")
        self._caption = new_caption

    def end_of_game(self, note):
        """Дії при завершенні гри"""
        string = pygame.font.SysFont('serif', 48)
        text2 = string.render(note, 0, (255, 255, 255))
        surf = pygame.Surface((450, 450))
        surf.fill((60, 10, 180))
        surf.set_alpha(150)
        self.screen.blit(surf, (25, 25))
        self.screen.blit(text2, (120, 170))

    def fill_screen_background(self):
        """Заповнення фону"""
        surf = pygame.Surface((450, 450))
        surf.fill((60, 10, 180))
        self.screen.blit(surf, (25, 25))

    def show_player_now(self, player, O_image, X_image):
        """Виведення фігури грвця, який зараз ходить"""
        if player == "X":
            self.screen.blit(X_image, (575, 30))
        else:
            self.screen.blit(O_image, (575, 30))