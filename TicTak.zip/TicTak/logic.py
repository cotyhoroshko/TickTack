import pygame


class Logic:
    def __init__(self):
        self._game_not_over = True
        self.mouse_koorditations = [0, 0]
        self.mouse_status = "Up"

    def set_game_not_over(self, new_logic):
        self._game_not_over = new_logic

    def get_game_not_over(self):
        return self._game_not_over

    def button_logic(self, inp_s):
        """Керування кнопками *СТАРТ* та *ВИХІД* відносно дій користувача"""
        get_chat_down = "NO"
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.set_game_not_over(False)

            if event.type == pygame.MOUSEBUTTONDOWN:
                self.mouse_koorditations = pygame.mouse.get_pos()
                self.mouse_status = "Down"

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    get_chat_down = "DOWN"
                if event.key == pygame.K_UP:
                    get_chat_down = "UP"

            if event.type == pygame.MOUSEBUTTONUP:
                self.mouse_status = "Up"

            inp_s.get_event(event)
            return get_chat_down

    def input_logic(self, inputs_p):
        print("input logic")
        print(pygame.event.get())
        for event in pygame.event.get():
            print("evv")
            inputs_p.get_event(event)
            print("ev")

    def game_logic(self, list_of_buttons):
        """Логіка ігрового процесу"""
        over = 0
        for i in list_of_buttons:
            if i.button_status != "Nothing":
                over += 1
        if over == 9:
            return "Nobody won"

        start = 0
        end = 3
        for _ in range(3):
            x = 0
            o = 0
            for i in range(start, end):
                if list_of_buttons[i].button_status != "Nothing" and list_of_buttons[i].button_status == "X":
                    x += 1
                if list_of_buttons[i].button_status != "Nothing" and list_of_buttons[i].button_status == "O":
                    o += 1
            if x == 3:
                return "Winner: X"
            if o == 3:
                return "Winner: O"
            start += 3
            end += 3
        start = 0
        mid = 3
        end = 6
        for _ in range(3):
            x = 0
            o = 0
            if list_of_buttons[start].button_status == "X" and \
                    list_of_buttons[mid].button_status == "X" and \
                    list_of_buttons[end].button_status == "X":
                return "Winner: X"
            if list_of_buttons[start].button_status == "O" and \
                    list_of_buttons[mid].button_status == "O" and \
                    list_of_buttons[end].button_status == "O":
                return "Winner: O"
            start += 1
            mid += 1
            end += 1
        start = 0
        mid = 4
        end = 8
        for _ in range(2):
            if list_of_buttons[start].button_status == "X" and \
                    list_of_buttons[mid].button_status == "X" and \
                    list_of_buttons[end].button_status == "X":
                return "Winner: X"
            if list_of_buttons[start].button_status == "O" and \
                    list_of_buttons[mid].button_status == "O" and \
                    list_of_buttons[end].button_status == "O":
                return "Winner: O"
            start += 2
            end -= 2
        return "Nothing"
