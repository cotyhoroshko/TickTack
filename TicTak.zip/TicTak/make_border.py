import pygame

border = pygame.image.load("images/border_block.png")
border_end = pygame.image.load("images/border_block_end.png")
border_vertical = pygame.transform.rotate(border, 90)
border = pygame.transform.scale(border, (25, 25))
border_end = pygame.transform.scale(border_end, (25, 25))
border_vertical = pygame.transform.scale(border_vertical, (25, 25))

area = pygame.Surface((500, 500))

for x in range(0, 500, 25):
    if x == 0 or x == 25 or x == 450 or x == 475:
        area.blit(border_end, (x, 0))
        area.blit(border_end, (x, 475))
    else:
        area.blit(border_vertical, (x, 0))
        area.blit(border_vertical, (x, 475))

for y in range(25, 475, 25):
    if y == 25 or y == 450:
        area.blit(border_end, (0, y))
        area.blit(border_end, (475, y))
    else:
        area.blit(border, (0, y))
        area.blit(border, (475, y))

pygame.image.save(area, "images/area_border.png")

